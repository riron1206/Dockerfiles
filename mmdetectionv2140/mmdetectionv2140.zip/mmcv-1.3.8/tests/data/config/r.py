import os

os.environ["TEST_VALUE"] = 'test'
